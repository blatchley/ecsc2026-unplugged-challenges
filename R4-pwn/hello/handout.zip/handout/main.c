#include <stdio.h>
#include <unistd.h>

void hello() {
    char buf[0x60];
    puts("What's your name?");
    read(STDIN_FILENO, buf, 0x80);
    printf("Hello %s!\n", buf);
}

int main(void) {
    hello();
    return 0;
}
